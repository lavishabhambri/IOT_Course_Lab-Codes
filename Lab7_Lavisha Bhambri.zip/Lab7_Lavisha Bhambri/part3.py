import requests
import json
from datetime import datetime
import matplotlib.pyplot as plt

ae = "DHT11"
cnt = "node1"
headers = {
    'X-M2M-Origin' : 'admin:admin',
    'Content-type' : 'application/json'
}
rp = requests.get(f'http://127.0.0.1:8080/~/in-cse/in-name/{ae}/{cnt}/?rcn=4', headers=headers)
result = json.loads(rp.text)
vals = []
times = []
for var in result['m2m:cnt']['m2m:cin']:
    vals.append(var['con'])
    times.append(datetime.strptime(var['ct'], '%Y%m%dT%H%M%S'))

plt.plot(times, vals)
plt.xlabel('TimeStamp')
plt.ylabel('Values')
plt.show()