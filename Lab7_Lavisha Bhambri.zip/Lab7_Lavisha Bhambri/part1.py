from onem2m import *
uri_cse = "http://127.0.0.1:8080/~/in-cse/in-name"
ae = "DHT11"
cnt = "node1"
uri_ae = uri_cse + "/" + ae
uri_cnt = uri_ae + "/" + cnt

# Functions
create_ae(uri_cse, ae)
create_cnt(uri_ae, cnt)
create_data_cin(uri_cnt, "random_value")
